package uk.ac.aston.oop.javafx.assessed;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
public class CreateCDController {
	private boolean confirmed = false;
	public CreateCDController() {
		
	}
	
	@FXML private TextField titleText;
	
	@FXML private TextField artistText;
	
	@FXML private CheckBox ownedCheckbox;
	
	@FXML private Label playTimeL;
	
	@FXML private Slider sliderforPlayTime;
	
	@FXML private Label nTracksL;
	
	@FXML private Slider sliderforNTracks; 
	
	@FXML public void createPressed() {
		confirmed = true;
		titleText.getScene().getWindow().hide();
	}
	
	
	@FXML public void cancelPressed() {
		titleText.getScene().getWindow().hide();
	}
	
	public boolean isConfirmed() {
		return confirmed;
	}
	
	public String gettitleText() {
		return titleText.getText();
	}
	
	public String getartistText() {
		return artistText.getText();
	}
	
	public int getplayTimeval() {
	    double value = sliderforPlayTime.getValue();
	    int playTimeValue = (int) value;
	    return playTimeValue;
	}
	
	public int getntrackval() {
		 double value = sliderforNTracks.getValue();
		 int intValue = (int) value;
		 return intValue;
	}
	
	public boolean isOwnChecked() {
		return ownedCheckbox.isSelected();
		
	}
	
	@FXML
	public void initialize() {
	    final String initialSlider1 = playTimeL.getText();
	    final String initialSlider2 = nTracksL.getText();
	    
	    sliderforPlayTime.valueProperty().addListener((observable, oldVal, newVal) -> {
	        int value = newVal.intValue();
	        playTimeL.setText(initialSlider1 + value);
	    });
	    
	    sliderforNTracks.valueProperty().addListener((observable, oldVal, newVal) -> {
	        int value = newVal.intValue();
	        nTracksL.setText(initialSlider2 + value);
	    });
	}

}
